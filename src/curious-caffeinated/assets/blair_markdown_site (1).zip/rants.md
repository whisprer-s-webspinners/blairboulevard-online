---
title: Ranting is a Feminist Act
layout: includes/layout.njk
---
You call it angry, we call it articulate.  
Blair rants about everything from misogyny to low-rise jeans making a comeback.  
Warning: may contain truths and swearing.
