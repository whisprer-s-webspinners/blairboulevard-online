---
title: Fashion That Screams (In a Good Way)
layout: includes/layout.njk
---
Blair doesn’t follow fashion trends — she trips over them in chunky boots and starts new ones by accident.

From runway dreams to thrift-store screamers, welcome to a world of maximalist joy and subtle middle fingers to the patriarchy.
