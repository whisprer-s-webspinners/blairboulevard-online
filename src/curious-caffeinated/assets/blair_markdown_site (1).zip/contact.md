---
title: Contact Blair
layout: includes/layout.njk
---
Got a hot tip, cold tea, or burning question? Drop me a line and I might just shout about it.

📧 Email: totallynotblair@blairboulevard.online  
📬 Snail mail: Ask a pigeon. I’ll get it eventually.
