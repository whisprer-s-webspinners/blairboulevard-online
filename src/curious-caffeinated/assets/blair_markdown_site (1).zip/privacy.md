---
title: Privacy Schmivacy
layout: includes/layout.njk
---
Look, we don’t *want* your data. We barely want our own drama. But the internet works in mysterious, cookie-shaped ways.

We promise to treat your info with more respect than that one ex who ghosted you.
