---
title: Dating & Disasters
layout: includes/layout.njk
---
Love is messy. Dating is messier.  
Here’s where Blair spills all the tea, wine, and leftover dignity about finding connection in a world of weirdos.
