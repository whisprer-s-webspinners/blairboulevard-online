---
title: Self-Care & Emotional Mayhem
layout: includes/layout.njk
---
Candles, rage journaling, and skincare routines that double as exorcisms.  

Self-care isn’t soft — sometimes it’s scream therapy and deleting numbers. Blair-style.
