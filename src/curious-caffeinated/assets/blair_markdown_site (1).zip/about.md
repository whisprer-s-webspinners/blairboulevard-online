---
title: About Blair
layout: includes/layout.njk
---
Hey, I’m **Blair Boulevard**. Loud mouth, big heart, bigger opinions. I'm the voice in your head when you try to make bad decisions, and the shoulder you cry on when they go wrong anyway.

I write about women’s lives, love, lippy, loss, and all the lipstick-smudged truths we live through.
