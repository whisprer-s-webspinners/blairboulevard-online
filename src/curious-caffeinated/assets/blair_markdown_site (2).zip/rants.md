---
title: Rants
layout: layout.njk
---

# Rants

Oh, I’ve got thoughts.  
And they don’t always fit into neat little posts. When I go off, it lands here.

