---
title: Home
layout: layout.njk
---

# Blair Boulevard

Welcome to the world of hot takes, real talk, and unapologetic truth bombs. I'm **Blair Boulevard** — your high-heeled hurricane of honesty. Sit down, pour a glass of something strong, and let’s rip the lace off the lies.

Explore:
- [About Me](about.md)
- [Contact](contact.md)
- [Fashion](fashion.md)
- [Self-Care](self-care.md)
- [Dating](dating.md)
- [Rants](rants.md)
- [Privacy](privacy.md)
