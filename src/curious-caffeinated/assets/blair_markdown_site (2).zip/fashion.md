---
title: Fashion
layout: layout.njk
---

# Fashion

If your outfit doesn’t make you feel dangerous, why bother?  
Here’s where I log the fits, flops, and fashion fights.

