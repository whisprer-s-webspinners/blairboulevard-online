---
title: Dating
layout: layout.njk
---

# Dating

Love is war.  
Sometimes you’re the grenade. Sometimes you’re the smoke bomb.  
These are my dispatches from the front.

