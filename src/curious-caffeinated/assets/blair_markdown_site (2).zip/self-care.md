---
title: Self-Care
layout: layout.njk
---

# Self-Care

Self-care isn’t always bubble baths and rose quartz. Sometimes it’s saying *no*, blocking an ex, or cutting your bangs. Let’s talk rituals, routines, and radical self-love.

