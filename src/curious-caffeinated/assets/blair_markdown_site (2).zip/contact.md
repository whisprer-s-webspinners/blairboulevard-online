---
title: Contact
layout: layout.njk
---

# Contact Blair

Wanna collab? Scream into the void? Just say hi?

**Email:** blair@boulevardmail.com  
**Instagram:** [@blair.boulevard](https://instagram.com/blair.boulevard)  
**DMs:** Occasionally open. Always glittery.

