---
title: Privacy
layout: layout.njk
---

# Privacy Policy

I’m not here to steal your secrets. I’m here to spill mine. But if you’re worried about cookies, trackers, and the like — know this site doesn’t snitch. I respect your vibe.

