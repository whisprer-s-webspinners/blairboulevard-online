---
title: About Blair
layout: layout.njk
---

# About Me

Hi, I’m Blair. Loud. Opinionated. Feminine as hell. I’ve walked the stilettos of hell and back and learned a few things along the way. This site? My megaphone. My diary. My firebrand.

Expect wit. Expect style. Expect a refusal to apologize.

